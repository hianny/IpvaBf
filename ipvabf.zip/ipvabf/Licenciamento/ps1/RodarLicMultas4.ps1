C:\IpvaBf\IPVABF\.venv\Scripts\activate.ps1
cd C:\IpvaBf\IPVABF
python .\ipvabf\Licenciamento\MainLicenciamento.py "4"